package com.tommy.spring.config;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice   //RestControllerAdvice controller 增强器
public class ErrorManage {
    //监听只要spring有Exception错误就调用这个方法
    @ExceptionHandler(RuntimeException.class)
    public Map<String, String> SysException(RuntimeException e) {
        Map<String,String> map = new HashMap<>();
        map.put("error","服务器错误:"+e.toString());
        return map;
    }
}
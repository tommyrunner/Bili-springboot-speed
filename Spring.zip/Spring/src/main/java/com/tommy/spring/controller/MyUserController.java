package com.tommy.spring.controller;

import com.tommy.spring.entity.SqlMyUser;
import com.tommy.spring.service.MyUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author Tommy
 * 2021/4/6
 */
//@Controller
//@ResponseBody //将java对象转为json格式的数据。
@RestController
@Slf4j
@Api(value = "用户接口")
public class MyUserController {

    @Autowired
    MyUserService myUserService;

    //查询所有用户
    @GetMapping("/getSqlMyUserAll")
    @ApiOperation(value = "获取所有用户")
    public List<SqlMyUser> getSqlMyUserAll(){
        log.info("------访问了查询所有用户-----");
        log.debug("------测试时候:访问了查询所有用户-----");
       return myUserService.findMyUserAll();
    }

    //根据用户名查询用户
    @GetMapping("/getSqlMyUser")
    @ApiOperation(value = "根据用户名查询用户")
    public SqlMyUser getSqlMyUser(@ApiParam(value = "用户名user") String user){
        return myUserService.findMyUserByUser(user);
    }
    //根据用户id查询用户
    @GetMapping("/getSqlMyId")
    @ApiOperation(value = "根据用户id查询用户")
    public SqlMyUser getSqlMyId(@ApiParam(value = "用户名唯一id") SqlMyUser sqlMyUser){
        return myUserService.findMyUserById(sqlMyUser.getId());
    }
    //添加
    @PostMapping("/saveMyUser")
    @ApiOperation(value = "添加用户")
    public Map<String, Object> saveMyUser(@ApiParam(value = "用户对象") SqlMyUser sqlMyUser, MultipartFile image){
        try {
            return myUserService.saveSqlMyUser(sqlMyUser,image);
        } catch (Exception e) {
            return  null;
        }
    }
    //删除
    @PostMapping("/deleteMyUser")
    @ApiOperation(value = "删除用户")
    public String deleteMyUser(@ApiParam(value = "用户唯一id")SqlMyUser sqlMyUser){
        myUserService.deleteByIdMyUser(sqlMyUser.getId());
        return "删除成功!";
    }
}

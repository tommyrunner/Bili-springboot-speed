package com.tommy.spring.service;

import com.tommy.spring.annotation.ClickLock;
import com.tommy.spring.dao.SqlMyUserDao;
import com.tommy.spring.entity.SqlMyUser;
import com.tommy.spring.utils.FileUtil;
import com.tommy.spring.utils.OssManagerUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author Tommy
 * 2021/4/11
 */
@Service
@CacheConfig(cacheNames = "User",cacheManager = "myCacheManager")
public class MyUserService {
    @Autowired
    SqlMyUserDao sqlMyUserDao;
    @Autowired
    OssManagerUtil ossManagerUtil;
    //查询
//    @ClickLock(key = "MyUserService/findMyUserAll")
    @Cacheable(value = "'findMyUserAll'")
    public List<SqlMyUser> findMyUserAll(){
       return sqlMyUserDao.findAll();
    }
    //根据用户名查询
    public SqlMyUser findMyUserByUser(String user){
        return sqlMyUserDao.findByUser(user);
    }
    //根据用户id查询
    @Cacheable(value = "#id")
    public SqlMyUser findMyUserById(int id){
        return sqlMyUserDao.findById(id).get();
    }
    //删除
    @Transactional
    @CacheEvict(value = "#id")
    public void deleteByIdMyUser(Integer id){
        sqlMyUserDao.deleteById(id);
//        int i = 1/0;
        //...
    }
    //添加/修改
    @Transactional
    public Map<String,Object> saveSqlMyUser(SqlMyUser sqlMyUser, MultipartFile image) throws Exception {
        String test = ossManagerUtil.upLoad(FileUtil.multipartFileToFile(image), "test", sqlMyUser.getUser() + ".png");
        SqlMyUser save = sqlMyUserDao.save(sqlMyUser);
        Map<String,Object> map = new HashMap<>();
        map.put("userImage",test);
        map.put("user",save);
        return map;
    }
}

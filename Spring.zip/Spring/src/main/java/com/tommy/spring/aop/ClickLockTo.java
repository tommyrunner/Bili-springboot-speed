package com.tommy.spring.aop;

import com.tommy.spring.annotation.ClickLock;
import lombok.SneakyThrows;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StringUtils;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

@Configuration
@Aspect
public class ClickLockTo {
    //准备一个缓存池
    private static final Map<String, Object> CACHES = new HashMap<>();

    //接受到所有的注解
    //拦截所有的public方法并且注释为ClickLock
    //注意：你注解了多少个方法就会调用几次
    @Around("execution(public * *(..))&&@annotation(com.tommy.spring.annotation.ClickLock)")
    public Object interceptor(ProceedingJoinPoint pjp) {
        //获取注解中的参数和方法里的参数
        MethodSignature signature = (MethodSignature) pjp.getSignature();
        Method method = signature.getMethod();
        ClickLock clickLock = method.getAnnotation(ClickLock.class);
        //获取的参数集合pjp.getArgs():所有注解的方法里的参数
        //clickLock.key()：获取注解上的属性值
        String key = clickLock.key();
        if (!StringUtils.isEmpty(key)) { //不能为空
            if (CACHES.get(key) != null) {
                //找到了，里面存入过（刚刚访问过）
                System.out.println("----------重新插入");
                throw new RuntimeException("不能重复点击");

            } else {
                //没存过
                CACHES.put(key, key);
                System.out.println("----------插入");
                new Thread() {
                    @SneakyThrows
                    @Override
                    public void run() {
                        sleep(1000);
                        CACHES.remove(key);
                    }
                }.start();
            }
        }
        try {
            return pjp.proceed();  //继续执行
        } catch (Throwable throwable) {
            throwable.printStackTrace();
            throw new RuntimeException("错误");
        }
    }
}
package com.tommy.spring.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.*;

/**
 * @Author Tommy
 * 2021/4/11
 */
@Entity
@Table(name = "tb_user")
@Data
public class SqlMyUser {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
            @ApiModelProperty(value = "用户唯一id")
    int id;
    @Column
    @ApiModelProperty(value = "用户user")
    String user;
    @Column
    @ApiModelProperty(value = "用户密码")
    String pwd;
    @Column
    @ApiModelProperty(value = "节点")
    String node;
}
